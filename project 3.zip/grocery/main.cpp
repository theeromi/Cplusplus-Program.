/*
Done by Romain Tomlinson
*/

#include <iostream>
#include <fstream>
#include <map>
#include <vector>
#include <string>

using namespace std;

class GroceryTracker {
private:
  map<string, int> item_count;
  string input_file = "CS210_Project_Three_Input_File.txt";
  string output_file = "frequency.dat";

public:
  // Constructor
  GroceryTracker() {
    // Read from input file and count frequency of each item
    ifstream input(input_file);
    if (input.is_open()) {
      string item;
      while (input >> item) {
        item_count[item]++;
      }
      input.close();
    }
    // Write to output file for backup purposes
    ofstream output(output_file);
    if (output.is_open()) {
      for (const auto &[item, count] : item_count) {
        output << item << " " << count << endl;
      }
      output.close();
    }
  }

  // Menu Option One
  void searchItem() {
    string item;
    cout << "Enter item name: ";
    cin >> item;
    if (item_count.count(item) > 0) {
      cout << "Frequency of " << item << ": " << item_count[item] << endl;
    } else {
      cout << "Item not found." << endl;
    }
  }

  // Menu Option Two
  void printList() {
    cout << "List of items and their frequencies:" << endl;
    for (const auto &[item, count] : item_count) {
      cout << item << ": " << count << endl;
    }
  }

  // Menu Option Three
  void printHistogram() {
    cout << "Histogram of items and their frequencies:" << endl;
    for (const auto &[item, count] : item_count) {
      cout << item << ": ";
      for (int i = 0; i < count; i++) {
        cout << "*";
      }
      cout << endl;
    }
  }
};

int main() {
  GroceryTracker tracker;
  int option;
  do {
    cout << "Grocery Tracker Menu:" << endl;
    cout << "1. Search for item frequency" << endl;
    cout << "2. Print list of items and frequencies" << endl;
    cout << "3. Print histogram of items and frequencies" << endl;
    cout << "4. Exit" << endl;
    cout << "Enter option (1-4): ";
    cin >> option;
    switch (option) {
      case 1:
        tracker.searchItem();
        break;
      case 2:
        tracker.printList();
        break;
      case 3:
        tracker.printHistogram();
        break;
      case 4:
        break;
      default:
        cout << "Invalid option. Please try again." << endl;
        break;
    }
  } while (option != 4);
  return 0;
}
